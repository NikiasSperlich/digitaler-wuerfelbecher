﻿using System;
using System.Windows;
using System.Threading;
using System.Windows.Input;
using System.Threading.Tasks;
using System.Text.RegularExpressions;

namespace WuerfelBecher{
    public partial class MainWindow : Window{

        //Initialisierung der Variablen
        Random rnd = new Random();
        int Wuerfe = 0;
        int intSummeWuerfe = 0;

        public MainWindow(){
            InitializeComponent();
        }

        //Initalisierung der Bindings um Einträge in der Listview setzen zu können
        public class ListViewEintrag{
            public int Nr { get; set; }
            public string Ergebnis { get; set; }
        }

        private async void Wuerfeln_Click(object sender, RoutedEventArgs e){
            //Prüfen ob Textbox Null ist
            if (TBWuerfeAnzahl.Text == null){
                TBWuerfeAnzahl.Text ="0";
            }
            else{
                //Während  Würfel vorgang deaktiviert
                Wuerfeln.IsEnabled = false;

                //Liste und Summe zurücksetzen bei beginn
                LvErgebnisse.Items.Clear();
                LblSummeWuerfe.Content = "Summe der Würfe: ";

                //erstellen eines Arrays in Größe der Würfe
                Wuerfe = Int32.Parse(TBWuerfeAnzahl.Text);
                int[] WurfErgebnisse = new int[Wuerfe];

                //Schleife um Würfel durchgang zu Simulieren
                for (int i = 0; i < Wuerfe; i++){
                    //erstellen zufälliger Zahl und speichern im Array
                    int wurf = rnd.Next(1, 7);
                    WurfErgebnisse[i] = wurf;
                    //Würfel Ergebnis anzeigen und Listbox hinzufügen, 1sek Delay für längere Sichtbarkeit
                    LblWuerfeErgebnis.Content = WurfErgebnisse[i];
                    LvErgebnisse.Items.Add(new ListViewEintrag { Nr = i + 1, Ergebnis = wurf.ToString() });
                    await Task.Delay(1000);
                }

                //Summe aller Würfelergebnisse berechnen
                for (int i = 0; i < Wuerfe; i++){
                    intSummeWuerfe += WurfErgebnisse[i];
                }
                LblSummeWuerfe.Content = "Summe der Würfe: " + intSummeWuerfe;
                Wuerfeln.IsEnabled = true;
            }
        }

        //Verhindern von Buchstaben, Sonderzeichen usw
        private void TBWuerfeAnzahl_PreviewTextInput(object sender, TextCompositionEventArgs e){
            e.Handled = !Regex.IsMatch(e.Text, "^[0-9]+$");
        }

        private void BtnBreak_Click(object sender, RoutedEventArgs e)
        {
            MainWindow neu = new MainWindow();
            Application.Current.MainWindow = neu;
            this.Close();
            neu.Show();
        }
    }
}



